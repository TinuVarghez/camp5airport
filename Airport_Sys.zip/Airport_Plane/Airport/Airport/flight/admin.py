from django.contrib import admin
# Register your models here.
from .models import Flight
admin.site.register(Flight)